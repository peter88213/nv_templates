"""nv_templates installer library module. 

Version 5.4.0

Copyright (c) 2025 Peter Triesberger
For further information see https://github.com/peter88213/nv_templates
License: GNU GPLv3 (https://www.gnu.org/licenses/gpl-3.0.en.html)
"""
import os
from pathlib import Path
from shutil import copy2
from shutil import copytree
import sys
import zipfile

PLUGIN = 'nv_templates.py'
VERSION = '5.4.0'
SAMPLE_PATH = 'sample/'

pyz = os.path.dirname(__file__)


def extract_file(sourceFile, targetDir):
    with zipfile.ZipFile(pyz) as z:
        z.extract(sourceFile, targetDir)


def extract_tree(sourceDir, targetDir):
    with zipfile.ZipFile(pyz) as z:
        for file in z.namelist():
            if file.startswith(f'{sourceDir}/'):
                z.extract(file, targetDir)


def cp_tree(sourceDir, targetDir):
    copytree(sourceDir, f'{targetDir}/{sourceDir}', dirs_exist_ok=True)


def extract_templates(templateDir):
    with zipfile.ZipFile(pyz) as z:
        for file in z.namelist():
            if file.startswith(SAMPLE_PATH):
                targetFile = file.replace(SAMPLE_PATH, '')
                if not targetFile:
                    continue
                if os.path.isfile(f'{templateDir}/{targetFile}'):
                    print(f'Overwriting "{templateDir}/{targetFile}" ...')
                else:
                    print(f'Copying "{templateDir}/{targetFile}" ...')
                with open(f'{templateDir}/{targetFile}', 'wb') as f:
                    f.write(z.read(file))


def cp_templates(templateDir):
    try:
        with os.scandir(SAMPLE_PATH) as files:
            for file in files:
                if os.path.isfile(f'{templateDir}/{file.name}'):
                    print(f'Overwriting "{templateDir}/{file.name}" ...')
                else:
                    print(f'Copying "{file.name}" ...')
                copy2(f'{SAMPLE_PATH}/{file.name}', f'{templateDir}/{file.name}')
    except:
        pass


def install(zipped):
    if zipped:
        copy_file = extract_file
        copy_tree = extract_tree
        copy_templates = extract_templates
    else:
        copy_file = copy2
        copy_tree = cp_tree
        copy_templates = cp_templates

    scriptPath = os.path.abspath(sys.argv[0])
    scriptDir = os.path.dirname(scriptPath)
    os.chdir(scriptDir)

    print(f'*** Installing {PLUGIN} {VERSION} ***\n')
    homePath = str(Path.home()).replace('\\', '/')
    applicationDir = f'{homePath}/.novx'
    if os.path.isdir(applicationDir):
        pluginDir = f'{applicationDir}/plugin'
        os.makedirs(pluginDir, exist_ok=True)

        # Install the plugin.
        print(f'Copying "{PLUGIN}" ...')
        copy_file(PLUGIN, pluginDir)

        # Install the localization files.
        print('Copying locale ...')
        copy_tree('locale', applicationDir)

        # Install the icon files.
        print('Copying icons ...')
        copy_tree('icons', applicationDir)

        # Install the sample templates.
        templateDir = f'{applicationDir}/templates'
        os.makedirs(templateDir, exist_ok=True)
        copy_templates(templateDir)

        # Show a success message.
        print(
            f'\nSucessfully installed {PLUGIN} '
            f'at "{os.path.normpath(pluginDir)}".'
        )
    else:
        print(
            'ERROR: Cannot find a novelibre installation '
            f'at "{os.path.normpath(applicationDir)}".'
        )

    input('Press ENTER to quit.')


def main(zipped=True):
    try:
        install(zipped)
    except Exception as ex:
        print(str(ex))
        input('Press ENTER to quit.')

