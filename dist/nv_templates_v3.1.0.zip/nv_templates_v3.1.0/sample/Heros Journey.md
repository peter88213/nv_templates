# Departure

## Call to Adventure

## Refusal of the Call

## Supernatural Aid/Guide Appears

## Crossing the 1st threshold

Leaving behind the known.

## Belly of the Whale

Final separation between their world & new world. Lowest part/transition.

# Initiation

## Road of Trials/Ordeal

3 tests, often fail.

## Meeting with the Goddess.

Union of Opposites, all encompassing love.

## Woman as temptress

Revulsion to our fleshly nature. Temptations to abandon journey.

## Atonement with the father

Meet up with the ultimate power & all is forgiven.

## Deification/Apotheosis.

Reach a godlike state of peace fulfillment & Clarity.

## Ultimate Boon

Achieving the quests goal.

# Return

## Refusal of the return

## Magic Flight

## Rescue from Without

## Crossing the Return Threshold

## Master of Two Worlds

## Freedom to live without fear of death


