"""A "Story Templates" plugin for novelibre.

Version 4.1.3

Adds a 'Add Story Templates' entry to the 'Tools' menu to open a window
with a combobox that lists all available themes. 
The selected theme will be persistently applied.  

Requires Python 3.6+
Copyright (c) 2024 Peter Triesberger
For further information see https://github.com/peter88213/nv_templates
License: GNU GPLv3 (https://www.gnu.org/licenses/gpl-3.0.en.html)

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
"""
import os
from pathlib import Path
from tkinter import filedialog
from tkinter import messagebox
import webbrowser

import sys
import gettext
import locale

ROOT_PREFIX = 'rt'
CHAPTER_PREFIX = 'ch'
CH_ROOT = f'{ROOT_PREFIX}{CHAPTER_PREFIX}'


class Error(Exception):
    pass


LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
try:
    CURRENT_LANGUAGE = locale.getlocale()[0][:2]
except:
    CURRENT_LANGUAGE = locale.getdefaultlocale()[0][:2]
try:
    t = gettext.translation('nv_templates', LOCALE_PATH, languages=[CURRENT_LANGUAGE])
    _ = t.gettext
except:

    def _(message):
        return message


def norm_path(path):
    if path is None:
        path = ''
    return os.path.normpath(path)

from abc import ABC, abstractmethod


class PluginBase(ABC):
    VERSION = ''
    API_VERSION = ''
    DESCRIPTION = ''
    URL = ''

    def __init__(self):
        self.filePath = None
        self.isActive = True
        self.isRejected = False

    @abstractmethod
    def install(self, model, view, controller, prefs=None):
        pass

    def disable_menu(self):
        pass

    def enable_menu(self):
        pass

    def lock(self):
        pass

    def on_close(self):
        pass

    def on_quit(self):
        pass

    def unlock(self):
        pass


class MdTemplate:
    DESCRIPTION = _('Story Template')
    EXTENSION = '.md'

    def __init__(self, filePath, model, controller):
        self.filePath = filePath
        self._mdl = model
        self._ctrl = controller

    def read(self):
        try:
            with open(self.filePath, 'r', encoding='utf-8') as f:
                mdLines = f.readlines()
        except(FileNotFoundError):
            raise Error(f'{_("File not found")}: "{norm_path(self.filePath)}".')
        except:
            raise Error(f'{_("Cannot read file")}: "{norm_path(self.filePath)}".')

        if mdLines[0].startswith('# nv'):
            self.read_novelyst_structure(mdLines)
        else:
            self.read_noveltree_structure(mdLines)

    def read_novelyst_structure(self, mdLines):
        chId = self._ctrl.add_chapter(targetNode=CH_ROOT, title=_('Stages'), chLevel=2, chType=3)
        scId = chId
        arcSection = False
        newElement = None
        notes = []
        for mdLine in mdLines:
            mdLine = mdLine.strip()
            if mdLine.startswith('#'):
                if newElement is not None:
                    newElement.notes = ''.join(notes).strip().replace('  ', ' ')
                    notes = []
                    newElement = None
                if mdLine.startswith('####'):
                    if arcSection:
                        newTitle = mdLine[5:]
                        scId = self._ctrl.add_stage(targetNode=scId, title=newTitle, scType=3)
                        if scId:
                            newElement = self._mdl.novel.sections[scId]
                elif mdLine.startswith('###'):
                    if not arcSection:
                        newTitle = mdLine[4:]
                        scId = self._ctrl.add_stage(targetNode=scId, title=newTitle, scType=2)
                        if scId:
                            newElement = self._mdl.novel.sections[scId]
                elif mdLine.strip() == '# pl':
                    arcSection = True
            elif mdLine:
                notes.append(f'{mdLine} ')
            else:
                notes.append('\n')
        try:
            newElement.notes = ''.join(notes).strip().replace('  ', ' ')
        except AttributeError:
            pass

    def read_noveltree_structure(self, mdLines):
        if self._mdl.novel.chapters:
            self.list_stages(mdLines)
        else:
            self.create_chapter_structure(mdLines)

    def create_chapter_structure(self, mdLines):
        i = 0
        chId = CH_ROOT
        addChapter = True
        newElement = None
        notes = []
        for mdLine in mdLines:
            mdLine = mdLine.strip()
            if mdLine.startswith('#'):
                if newElement is not None:
                    newElement.notes = ''.join(notes).strip().replace('  ', ' ')
                    notes = []
                    newElement = None
                if mdLine.startswith('## '):
                    if addChapter:
                        i += 1
                        chId = self._ctrl.add_chapter(targetNode=chId, title=f"{_('Chapter')} {i}", chLevel=2, chType=0)
                        scId = chId
                    newTitle = mdLine[3:].strip()
                    scId = self._ctrl.add_stage(targetNode=scId, title=newTitle, scType=3)
                    newElement = self._mdl.novel.sections[scId]
                    scId = self._ctrl.add_section(targetNode=scId, title=_('New Section'), scType=0, status=1)
                    addChapter = True
                elif mdLine.startswith('# '):
                    i += 1
                    chId = self._ctrl.add_chapter(targetNode=chId, title=f"{_('Chapter')} {i}", chLevel=2, chType=0)
                    newTitle = mdLine[2:].strip()
                    scId = self._ctrl.add_stage(targetNode=chId, title=newTitle, scType=2)
                    newElement = self._mdl.novel.sections[scId]
                    addChapter = False
                else:
                    scId = None
            elif mdLine:
                notes.append(f'{mdLine} ')
            else:
                notes.append('\n')
        try:
            newElement.notes = ''.join(notes).strip().replace('  ', ' ')
        except AttributeError:
            pass

    def list_stages(self, mdLines):
        chId = self._ctrl.add_chapter(targetNode=CH_ROOT, title=_('Stages'), chLevel=2, chType=3)
        scId = chId
        newElement = None
        notes = []
        for mdLine in mdLines:
            mdLine = mdLine.strip()
            if mdLine.startswith('#'):
                if newElement is not None:
                    newElement.notes = ''.join(notes).strip().replace('  ', ' ')
                    notes = []
                    newElement = None
                if mdLine.startswith('## '):
                    newTitle = mdLine[3:].strip()
                    scId = self._ctrl.add_stage(targetNode=scId, title=newTitle, scType=3)
                elif mdLine.startswith('# '):
                    newTitle = mdLine[2:].strip()
                    scId = self._ctrl.add_stage(targetNode=scId, title=newTitle, scType=2)
                else:
                    scId = None
                if scId:
                    newElement = self._mdl.novel.sections[scId]
            elif mdLine:
                notes.append(f'{mdLine} ')
            else:
                notes.append('\n')
        try:
            newElement.notes = ''.join(notes).strip().replace('  ', ' ')
        except AttributeError:
            pass

    def write(self):
        mdLines = []
        for chId in self._mdl.novel.tree.get_children(CH_ROOT):
            for scId in self._mdl.novel.tree.get_children(chId):
                if self._mdl.novel.sections[scId].scType == 2:
                    mdLines.append(f'# {self._mdl.novel.sections[scId].title}')
                    notes = self._mdl.novel.sections[scId].notes
                    if notes:
                        mdLines.append(notes.replace('\n', '\n\n'))
                elif self._mdl.novel.sections[scId].scType == 3:
                    mdLines.append(f'## {self._mdl.novel.sections[scId].title}')
                    notes = self._mdl.novel.sections[scId].notes
                    if notes:
                        mdLines.append(notes.replace('\n', '\n\n'))

        content = '\n\n'.join(mdLines)
        try:
            with open(self.filePath, 'w', encoding='utf-8') as f:
                f.write(content)
        except:
            raise Error(f'{_("Cannot write file")}: "{norm_path(self.filePath)}".')

import tkinter as tk

APPLICATION = _('Story Templates')
PLUGIN = f'{APPLICATION} plugin 4.1.3'


class Plugin(PluginBase):
    VERSION = '4.1.3'
    API_VERSION = '4.3'
    DESCRIPTION = 'A "Story Templates" manager'
    URL = 'https://github.com/peter88213/nv_templates'
    _HELP_URL = f'https://peter88213.github.io/{_("nvhelp-en")}/nv_templates/'

    def disable_menu(self):
        """Disable menu entries when no project is open.
        
        Overrides the superclass method.
        """
        self._templatesMenu.entryconfig(f"{_('Load')}...", state='disabled')
        self._templatesMenu.entryconfig(f"{_('Save')}...", state='disabled')

    def enable_menu(self):
        """Enable menu entries when a project is open.
        
        Overrides the superclass method.
        """
        self._templatesMenu.entryconfig(f"{_('Load')}...", state='normal')
        self._templatesMenu.entryconfig(f"{_('Save')}...", state='normal')

    def install(self, model, view, controller, prefs=None):
        """Add a submenu to the 'Tools' menu.
        
        Positional arguments:
            model -- reference to the main model instance of the application.
            view -- reference to the main view instance of the application.
            controller -- reference to the main controller instance of the application.

        Optional arguments:
            prefs -- deprecated. Please use controller.get_preferences() instead.
        
        Overrides the superclass method.
        """
        self._mdl = model
        self._ui = view
        self._ctrl = controller
        try:
            homeDir = str(Path.home()).replace('\\', '/')
            self._templateDir = f'{homeDir}/.novx/templates'
        except:
            self._templateDir = '.'

        self._templatesMenu = tk.Menu(self._ui.toolsMenu, tearoff=0)
        self._templatesMenu.add_command(label=f"{_('Load')}...", command=self._load_template)
        self._templatesMenu.add_command(label=f"{_('Save')}...", command=self._save_template)
        self._templatesMenu.add_command(label=_('Open folder'), command=self._open_folder)

        self._ui.newMenu.add_command(label=_('Create from template...'), command=self._new_project)

        self._ui.toolsMenu.add_cascade(label=APPLICATION, menu=self._templatesMenu)
        self._fileTypes = [(MdTemplate.DESCRIPTION, MdTemplate.EXTENSION)]

        self._ui.helpMenu.add_command(label=_('Templates plugin Online help'), command=lambda: webbrowser.open(self._HELP_URL))

    def _load_template(self):
        fileName = filedialog.askopenfilename(
            filetypes=self._fileTypes,
            defaultextension=self._fileTypes[0][1],
            initialdir=self._templateDir
            )
        if fileName:
            try:
                templates = MdTemplate(fileName, self._mdl, self._ctrl)
                templates.read()
            except Error as ex:
                messagebox.showerror(_('Template loading aborted'), str(ex))

    def _new_project(self):
        self._ctrl.new_project()
        self._load_template()

    def _open_folder(self):
        try:
            os.startfile(norm_path(self._templateDir))
        except:
            try:
                os.system('xdg-open "%s"' % norm_path(self._templateDir))
            except:
                try:
                    os.system('open "%s"' % norm_path(self._templateDir))
                except:
                    pass

    def _save_template(self):
        fileName = filedialog.asksaveasfilename(filetypes=self._fileTypes,
                                              defaultextension=self._fileTypes[0][1],
                                              initialdir=self._templateDir)
        if not fileName:
            return

        try:
            templates = MdTemplate(fileName, self._mdl, self._ctrl)
            templates.write()
        except Error as ex:
            messagebox.showerror(_('Cannot save template'), str(ex))

        self._ui.set_status(_('Template saved.'))

