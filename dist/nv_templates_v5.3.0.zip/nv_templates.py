"""A "Story Templates" plugin for novelibre.

Requires Python 3.7+
Copyright (c) 2025 Peter Triesberger
For further information see https://github.com/peter88213/nv_templates
License: GNU GPLv3 (https://www.gnu.org/licenses/gpl-3.0.en.html)

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
"""
import webbrowser

import os
import sys
import gettext
import locale

LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
try:
    CURRENT_LANGUAGE = locale.getlocale()[0][:2]
except:
    CURRENT_LANGUAGE = locale.getdefaultlocale()[0][:2]
try:
    t = gettext.translation(
        'nv_templates',
        LOCALE_PATH,
        languages=[CURRENT_LANGUAGE],
    )
    _ = t.gettext
except:

    def _(message):
        return message

from abc import ABC, abstractmethod
from pathlib import Path



class SubController:

    def disable_menu(self):
        pass

    def enable_menu(self):
        pass

    def lock(self):
        pass

    def on_close(self):
        pass

    def on_open(self):
        pass

    def on_quit(self):
        pass

    def unlock(self):
        pass

import tkinter as tk


class PluginBase(ABC, SubController):
    VERSION = ''
    API_VERSION = ''
    DESCRIPTION = ''
    URL = ''

    def __init__(self):
        self.filePath = None
        self.isActive = True
        self.isRejected = False

    @abstractmethod
    def install(self, model, view, controller):
        self._mdl = model
        self._ui = view
        self._ctrl = controller

    def uninstall(self):
        pass

    def _get_icon(self, fileName):
        if self._ctrl.get_preferences().get('large_icons', False):
            size = 24
        else:
            size = 16
        try:
            homeDir = str(Path.home()).replace('\\', '/')
            iconPath = f'{homeDir}/.novx/icons/{size}'
            icon = tk.PhotoImage(file=f'{iconPath}/{fileName}')
        except:
            icon = None
        return icon
from pathlib import Path
from tkinter import filedialog



class ServiceBase:

    def __init__(self, model, view, controller):
        self._mdl = model
        self._ui = view
        self._ctrl = controller


try:
    LOCALE_PATH
except NameError:
    locale.setlocale(locale.LC_TIME, "")
    LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
    try:
        CURRENT_LANGUAGE = locale.getlocale()[0][:2]
    except:
        CURRENT_LANGUAGE = locale.getdefaultlocale()[0][:2]
    try:
        t = gettext.translation(
            'novelibre',
            LOCALE_PATH,
            languages=[CURRENT_LANGUAGE],
        )
        _ = t.gettext
    except:

        def _(message):
            return message


ROOT_PREFIX = 'rt'
CHAPTER_PREFIX = 'ch'
PLOT_LINE_PREFIX = 'ac'
SECTION_PREFIX = 'sc'
PLOT_POINT_PREFIX = 'ap'
CHARACTER_PREFIX = 'cr'
LOCATION_PREFIX = 'lc'
ITEM_PREFIX = 'it'
PRJ_NOTE_PREFIX = 'pn'
CH_ROOT = f'{ROOT_PREFIX}{CHAPTER_PREFIX}'
PL_ROOT = f'{ROOT_PREFIX}{PLOT_LINE_PREFIX}'
CR_ROOT = f'{ROOT_PREFIX}{CHARACTER_PREFIX}'
LC_ROOT = f'{ROOT_PREFIX}{LOCATION_PREFIX}'
IT_ROOT = f'{ROOT_PREFIX}{ITEM_PREFIX}'
PN_ROOT = f'{ROOT_PREFIX}{PRJ_NOTE_PREFIX}'

BRF_SYNOPSIS_SUFFIX = '_brf_synopsis'
CHAPTERLIST_SUFFIX = '_chapterlist_tmp'
CHAPTERS_SUFFIX = '_chapters_tmp'
CHARACTER_REPORT_SUFFIX = '_character_report'
CHARACTERS_SUFFIX = '_characters_tmp'
CHARLIST_SUFFIX = '_charlist_tmp'
DATA_SUFFIX = '_data'
ELEMENT_NOTES_SUFFIX = '_element_note_report',
GRID_SUFFIX = '_grid_tmp'
ITEM_REPORT_SUFFIX = '_item_report'
ITEMLIST_SUFFIX = '_itemlist_tmp'
ITEMS_SUFFIX = '_items_tmp'
LOCATION_REPORT_SUFFIX = '_location_report'
LOCATIONS_SUFFIX = '_locations_tmp'
LOCLIST_SUFFIX = '_loclist_tmp'
MAJOR_MARKER = _('Major Character')
MANUSCRIPT_SUFFIX = '_manuscript_tmp'
MINOR_MARKER = _('Minor Character')
PARTLIST_SUFFIX = '_partlist_tmp'
PARTS_SUFFIX = '_parts_tmp'
PLOTLIST_SUFFIX = '_plotlist'
PLOTLINES_SUFFIX = '_plotlines_tmp'
PROJECTNOTES_SUFFIX = '_projectnote_report'
PROOF_SUFFIX = '_proof_tmp'
SECTIONLIST_SUFFIX = '_sectionlist'
SECTIONS_SUFFIX = '_sections_tmp'
STAGES_SUFFIX = '_structure_tmp'
TIMETABLE_SUFFIX = '_tt_tmp'
XREF_SUFFIX = '_xref'

NO_SCENE_FIELD_1_DEFAULT = _('Plot progress')
NO_SCENE_FIELD_2_DEFAULT = _('Characterization')
NO_SCENE_FIELD_3_DEFAULT = _('World building')
OTHER_SCENE_FIELD_1_DEFAULT = _('Opening')
OTHER_SCENE_FIELD_2_DEFAULT = _('Peak emotional moment')
OTHER_SCENE_FIELD_3_DEFAULT = _('Ending')
CR_FIELD_1_DEFAULT = _('Bio')
CR_FIELD_2_DEFAULT = _('Goals')

STATUS = [
    None,
    _('Outline'),
    _('Draft'),
    _('1st Edit'),
    _('2nd Edit'),
    _('Done')
]

SCENE = ['-', 'A', 'R', 'x']


def norm_path(path):
    if path is None:
        path = ''
    return os.path.normpath(path)


def string_to_list(text, divider=';'):
    elements = []
    try:
        tempList = text.split(divider)
        for element in tempList:
            element = element.strip()
            if element and not element in elements:
                elements.append(element)
        return elements

    except:
        return []


def list_to_string(elements, divider=';'):
    try:
        text = divider.join(elements)
        return text

    except:
        return ''


def intersection(elemList, refList):
    return [elem for elem in elemList if elem in refList]


def verified_int_string(intStr):
    if intStr is not None:
        int(intStr)
    return intStr



class MdTemplate:
    DESCRIPTION = _('Story Template')
    EXTENSION = '.md'

    def __init__(self, filePath, model, controller):
        self.filePath = filePath
        self._mdl = model
        self._ctrl = controller

    def read(self):
        try:
            with open(self.filePath, 'r', encoding='utf-8') as f:
                mdLines = f.readlines()
        except(FileNotFoundError):
            raise RuntimeError(
                f'{_("File not found")}: "{norm_path(self.filePath)}".'
            )
        except:
            raise RuntimeError(
                f'{_("Cannot read file")}: "{norm_path(self.filePath)}".'
            )

        if self._mdl.novel.chapters:
            self._create_stages(mdLines)
        else:
            self._create_chapter_structure(mdLines)

    def write(self):
        mdLines = []
        for chId in self._mdl.novel.tree.get_children(CH_ROOT):
            for scId in self._mdl.novel.tree.get_children(chId):
                if self._mdl.novel.sections[scId].scType == 2:
                    mdLines.append(f'# {self._mdl.novel.sections[scId].title}')
                    notes = self._mdl.novel.sections[scId].notes
                    if notes:
                        mdLines.append(notes.replace('\n', '\n\n'))
                elif self._mdl.novel.sections[scId].scType == 3:
                    mdLines.append(f'## {self._mdl.novel.sections[scId].title}')
                    notes = self._mdl.novel.sections[scId].notes
                    if notes:
                        mdLines.append(notes.replace('\n', '\n\n'))

        content = '\n\n'.join(mdLines)
        try:
            with open(self.filePath, 'w', encoding='utf-8') as f:
                f.write(content)
        except:
            raise RuntimeError(
                f'{_("Cannot write file")}: "{norm_path(self.filePath)}".'
            )

    def _create_chapter_structure(self, mdLines):
        i = 0
        chId = CH_ROOT
        addChapter = True
        newElement = None
        notes = []
        for mdLine in mdLines:
            mdLine = mdLine.strip()
            if mdLine.startswith('#'):
                if newElement is not None:
                    newElement.notes = ''.join(notes).strip().replace('  ', ' ')
                    notes.clear()
                    newElement = None
                if mdLine.startswith('## '):
                    if addChapter:
                        i += 1
                        chId = self._ctrl.add_new_chapter(
                            targetNode=chId,
                            title=f"{_('Chapter')} {i}",
                            chLevel=2,
                            chType=0,
                        )
                        scId = chId
                    newTitle = mdLine[3:].strip()
                    scId = self._ctrl.add_new_stage(
                        targetNode=scId,
                        title=newTitle,
                        scType=3,
                    )
                    newElement = self._mdl.novel.sections[scId]
                    scId = self._ctrl.add_new_section(
                        targetNode=scId,
                        title=_('New Section'),
                        scType=0,
                        status=1,
                    )
                    addChapter = True
                elif mdLine.startswith('# '):
                    i += 1
                    chId = self._ctrl.add_new_chapter(
                        targetNode=chId,
                        title=f"{_('Chapter')} {i}",
                        chLevel=2,
                        chType=0,
                    )
                    newTitle = mdLine[2:].strip()
                    scId = self._ctrl.add_new_stage(
                        targetNode=chId,
                        title=newTitle,
                        scType=2,
                    )
                    newElement = self._mdl.novel.sections[scId]
                    addChapter = False
                else:
                    scId = None
            elif mdLine:
                notes.append(f'{mdLine} ')
            else:
                notes.append('\n')
        try:
            newElement.notes = ''.join(notes).strip().replace('  ', ' ')
        except AttributeError:
            pass

    def _create_stages(self, mdLines):
        chId = self._ctrl.add_new_chapter(
            targetNode=CH_ROOT,
            title=_('Stages'),
            chLevel=2,
            chType=3,
        )
        scId = chId
        newElement = None
        notes = []
        for mdLine in mdLines:
            mdLine = mdLine.strip()
            if mdLine.startswith('#'):
                if newElement is not None:
                    newElement.notes = ''.join(notes).strip().replace('  ', ' ')
                    notes.clear()
                    newElement = None
                if mdLine.startswith('## '):
                    newTitle = mdLine[3:].strip()
                    scId = self._ctrl.add_new_stage(
                        targetNode=scId,
                        title=newTitle,
                        scType=3,
                    )
                elif mdLine.startswith('# '):
                    newTitle = mdLine[2:].strip()
                    scId = self._ctrl.add_new_stage(
                        targetNode=scId,
                        title=newTitle,
                        scType=2,
                    )
                else:
                    scId = None
                if scId:
                    newElement = self._mdl.novel.sections[scId]
            elif mdLine:
                notes.append(f'{mdLine} ')
            else:
                notes.append('\n')
        try:
            newElement.notes = ''.join(notes).strip().replace('  ', ' ')
        except AttributeError:
            pass



class TemplateService(ServiceBase):

    def __init__(self, model, view, controller):
        super().__init__(model, view, controller)
        try:
            homeDir = str(Path.home()).replace('\\', '/')
            self.templateDir = f'{homeDir}/.novx/templates'
        except:
            self.templateDir = '.'

    def load_template(self):
        if self._ctrl.check_lock():
            return

        fileName = filedialog.askopenfilename(
            filetypes=[(MdTemplate.DESCRIPTION, MdTemplate.EXTENSION)],
            defaultextension=MdTemplate.EXTENSION,
            initialdir=self.templateDir,
        )
        if fileName:
            try:
                templates = MdTemplate(fileName, self._mdl, self._ctrl)
                templates.read()
            except RuntimeError as ex:
                self._ui.show_error(
                    message=_('Template loading aborted'),
                    detail=str(ex),
                )

    def new_project(self):
        if self._ctrl.create_project():
            self.load_template()

    def open_folder(self):
        try:
            os.startfile(norm_path(self.templateDir))
        except:
            try:
                os.system('xdg-open "%s"' % norm_path(self.templateDir))
            except:
                try:
                    os.system('open "%s"' % norm_path(self.templateDir))
                except:
                    pass

    def save_template(self):
        fileName = filedialog.asksaveasfilename(
            filetypes=[(MdTemplate.DESCRIPTION, MdTemplate.EXTENSION)],
            defaultextension=MdTemplate.EXTENSION,
            initialdir=self.templateDir
        )
        if not fileName:
            return

        try:
            templates = MdTemplate(fileName, self._mdl, self._ctrl)
            templates.write()
        except RuntimeError as ex:
            self._ui.show_error(
                message=_('Cannot save template'),
                detail=str(ex)
            )

        self._ui.set_status(_('Template saved.'))



class NvMenu(tk.Menu, SubController):

    def __init__(self):
        super().__init__(tearoff=0)
        self.disableOnLock = []
        self.disableOnClose = []

    def disable_menu(self):
        for label in self.disableOnClose:
            self.entryconfig(label, state='disabled')

    def enable_menu(self):
        for label in self.disableOnClose:
            self.entryconfig(label, state='normal')

    def lock(self):
        for label in self.disableOnLock:
            self.entryconfig(label, state='disabled')

    def unlock(self):
        for label in self.disableOnLock:
            self.entryconfig(label, state='normal')



class Plugin(PluginBase):
    VERSION = '5.3.0'
    API_VERSION = '5.44'
    DESCRIPTION = 'A "Story Templates" manager'
    URL = 'https://github.com/peter88213/nv_templates'
    HELP_URL = f'{_("https://peter88213.github.io/nvhelp-en")}/nv_templates/'

    FEATURE = _('Story Templates')

    def disable_menu(self):
        self.pluginMenu.disable_menu()

    def enable_menu(self):
        self.pluginMenu.enable_menu()

    def install(self, model, view, controller):
        """Add a submenu to the 'Tools' menu.
        
        Positional arguments:
            model -- reference to the novelibre main model instance.
            view -- reference to the novelibre main view instance.
            controller -- reference to the novelibre main controller instance.

        Extends the superclass method.
        """
        super().install(model, view, controller)
        self.templateService = TemplateService(model, view, controller)
        self._icon = self._get_icon('templates.png')


        self.pluginMenu = NvMenu()

        label = f"{_('Load')}..."
        self.pluginMenu.add_command(
            label=label,
            command=self.load_template,
        )
        self.pluginMenu.disableOnClose.append(label)
        self.pluginMenu.disableOnLock.append(label)

        label = f"{_('Save')}..."
        self.pluginMenu.add_command(
            label=label,
            command=self.save_template,
        )
        self.pluginMenu.disableOnClose.append(label)

        label = _('Open folder')
        self.pluginMenu.add_command(
            label=label,
            command=self.open_folder,
        )

        label = _('Create from template...')
        self._ui.newMenu.add_command(
            label=label,
            image=self._icon,
            compound='left',
            command=self.new_project,
        )

        label = self.FEATURE
        self._ui.toolsMenu.add_cascade(
            label=label,
            image=self._icon,
            compound='left',
            menu=self.pluginMenu,
        )

        label = _('Templates plugin Online help')
        self._ui.helpMenu.add_command(
            label=label,
            image=self._icon,
            compound='left',
            command=self.open_help,
        )

    def load_template(self):
        self.templateService.load_template()

    def lock(self):
        self.pluginMenu.lock()

    def new_project(self):
        self.templateService.new_project()

    def open_folder(self):
        self.templateService.open_folder()

    def open_help(self, event=None):
        webbrowser.open(self.HELP_URL)

    def save_template(self):
        self.templateService.save_template()

    def unlock(self):
        self.pluginMenu.unlock()

